filename="catr2.cst";
cst = actxserver('CSTStudio.Application');
mws = invoke(cst, 'OpenFile', fullfile(cd,'cst',filename));
SelectTreeItem = mws.invoke('SelectTreeItem','2D/3D Results\E-Field\e1 [ffs]');

export = mws.invoke("ASCIIExport");
invoke(export,"Reset");
invoke(export,"FileName","cosis.txt");
invoke(export,"Mode","FixedNumber");
invoke(export,"StepX",98);
invoke(export,"StepY",98);
invoke(export,"StepZ",1);
invoke(export,"Execute");

%%




fid = fopen("test.txt");
tline = fgetl(fid);
historyCode = "";
y_field = [];
i = 0;
while ischar(tline)
    i = i+1;
    if i < 3
        tline = fgetl(fid);
        continue;
    end
    splitted_line = strsplit(tline," ");
    if splitted_line(2) == "0"
       y_field = [y_field str2double(splitted_line(7))+1j*str2double(splitted_line(8))];
    end
    tline = fgetl(fid);
end
