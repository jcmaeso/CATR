function[] = addToCstHistory(mws,command,VBA)
    mws.invoke("AddToHistory",command,VBA);
end